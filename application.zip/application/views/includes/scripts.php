<script src="<?= base_url()?>/assets/vendors/jquery/dist/jquery.min.js" type="text/javascript"></script>
    <script src="<?= base_url()?>/assets/vendors/popper.js/dist/umd/popper.min.js" type="text/javascript"></script>
    <script src="<?= base_url()?>/assets/vendors/bootstrap/dist/js/bootstrap.min.js" type="text/javascript"></script>
    <script src="<?= base_url()?>/assets/vendors/metisMenu/dist/metisMenu.min.js" type="text/javascript"></script>
    <script src="<?= base_url()?>/assets/vendors/jquery-slimscroll/jquery.slimscroll.min.js" type="text/javascript"></script>
    <!-- PAGE LEVEL PLUGINS-->
    <script src="<?= base_url()?>/assets/vendors/chart.js/dist/Chart.min.js" type="text/javascript"></script>
    <script src="<?= base_url()?>/assets/vendors/select2/dist/js/select2.full.min.js" type="text/javascript"></script>
    <script src="<?= base_url()?>/assets/vendors/jvectormap/jquery-jvectormap-2.0.3.min.js" type="text/javascript"></script>
    <script src="<?= base_url()?>/assets/vendors/jvectormap/jquery-jvectormap-world-mill-en.js" type="text/javascript"></script>
    <script src="<?= base_url()?>/assets/vendors/jvectormap/jquery-jvectormap-us-aea-en.js" type="text/javascript"></script>

 <script src="<?= base_url()?>/assets/vendors/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js" type="text/javascript"></script>
    <script src="<?= base_url()?>/assets/vendors/bootstrap-timepicker/js/bootstrap-timepicker.min.js" type="text/javascript"></script>
    <script src="<?= base_url()?>/assets/vendors/jquery-minicolors/jquery.minicolors.min.js" type="text/javascript"></script>
  <!-- PAGE LEVEL PLUGINS-->
    <script src="<?= base_url()?>/assets/vendors/DataTables/datatables.min.js" type="text/javascript"></script>



    <!-- CORE SCRIPTS-->
    <script src="<?= base_url()?>/assets/js/app.min.js" type="text/javascript"></script>
    <!-- PAGE LEVEL SCRIPTS-->
    <script src="<?= base_url()?>/assets/js/scripts/dashboard_1_demo.js" type="text/javascript"></script>