<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Produits_Finis extends MY_Controller {

	public function __construct() {
		parent::__construct();
		$this->Is_Connected();
	}


	public function Is_Connected()
	{

		if (empty($this->session->userdata('SUPERBAT_ID_USER')))
		{
			redirect(base_url('Login/'));
		}
	}

	public function index()
	{
		$data['title']="Liste de Produits";
		$tansfere = $this->Model->getRequete("SELECT tps.ID_TRANSFERER_STOCK,IF(tps.ID_TYPE_PRODUIT=1,'Toles','Clous') AS produit,tps.ID_TYPE_TOLES,tt.DESCRIPTION_TOLES,tps.ID_TYPE_CLOUS,tc.DESCRIPTION AS DESCRIPTION_CLOUS,tps.QUANTITE,tps.NUMERO_COLIS,tps.DATE_INSERT_TRANSFER,tps.ID_USER_EXPEDITEUR,user.NOM,user.PRENOM,tps.ID_TYPE_PRODUIT FROM transferer_prod_stock tps LEFT JOIN type_toles tt ON tt.ID_TYPE_TOLES = tps.ID_TYPE_TOLES LEFT JOIN type_clous tc ON tc.ID_TYPE_CLOUS = tps.ID_TYPE_CLOUS LEFT JOIN admin_user user ON user.ID_USER=tps.ID_USER_EXPEDITEUR WHERE STATUT_TRANSFER=1 ORDER BY tps.ID_TRANSFERER_STOCK DESC");
		$data['transferes'] = $tansfere;
		$this->load->view('Produits_Finis_List_View',$data);
	}



	public function listing()
	{

		$query_principal ="SELECT tps.ID_TRANSFERER_STOCK,IF(tps.ID_TYPE_PRODUIT=1,'Toles','Clous') AS produit,tps.ID_TYPE_TOLES,tt.DESCRIPTION_TOLES,tps.ID_TYPE_CLOUS,tc.DESCRIPTION AS DESCRIPTION_CLOUS,tps.QUANTITE,tps.NUMERO_COLIS,tps.DATE_INSERT_TRANSFER,tps.ID_USER_EXPEDITEUR,user.NOM,user.PRENOM,tps.ID_TYPE_PRODUIT FROM transferer_prod_stock tps LEFT JOIN type_toles tt ON tt.ID_TYPE_TOLES = tps.ID_TYPE_TOLES LEFT JOIN type_clous tc ON tc.ID_TYPE_CLOUS = tps.ID_TYPE_CLOUS LEFT JOIN admin_user user ON user.ID_USER=tps.ID_USER_EXPEDITEUR WHERE STATUT_TRANSFER=2" ;

		$var_search = !empty($_POST['search']['value']) ? $this->db->escape_like_str($_POST['search']['value']) : null;

		$limit = 'LIMIT 0,10';

		if (isset($_POST['length']) && $_POST['length'] != -1) {
			$limit = 'LIMIT ' . (isset($_POST["start"]) ? $_POST["start"] : 0) . ',' . $_POST["length"];
		}

		$order_by = '';

		$order_column = array('ID_TRANSFERER_STOCK', 'produit','type_clous.DESCRIPTION','user.NOM', 'user.PRENOM', 'NUMERO_COLIS', 'QUANTITE', 'DATE_INSERT_TRANSFER');

		$order_by = isset($_POST['order']) ? ' ORDER BY ' . $order_column[$_POST['order']['0']['column']] . '  ' . $_POST['order']['0']['dir'] : ' ORDER BY ID_TRANSFERER_STOCK ASC';

		$search = !empty($_POST['search']['value']) ?
		"AND produit LIKE '%$var_search%' OR type_clous.DESCRIPTION LIKE '%$var_search%' OR user.NOM LIKE '%$var_search%' OR user.PRENOM LIKE '%$var_search%'  LIKE '%$var_search%' OR DATE_FORMAT(DATE_INSERT_TRANSFER, '%d/%m/%Y') LIKE '%$var_search%' "
		: '';

		$critaire = '';

		$query_secondaire = $query_principal . ' ' . $critaire . ' ' . $search . ' ' . $order_by . '   ' . $limit;
		$query_filter = $query_principal . ' ' . $critaire . ' ' . $search;

		$resultat = $this->Model->datatable($query_secondaire);

		$data = array();
		foreach ($resultat as $key) {
			$row = array();

			$row[] = date("d/m/Y", strtotime($key->DATE_INSERT_TRANSFER));
			$row[] = $key->NOM." ".$key->PRENOM;
			$row[] = $key->produit;
			$row[] = $key->ID_TYPE_PRODUIT=1 ? $key->DESCRIPTION_TOLES :  $key->DESCRIPTION_CLOUS ;
			$row[] = $key->QUANTITE ;
			
			

			$row[] = '
			<div class="btn-group">
			<button type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
			<i class="fa fa-cogs"></i> Actions <i class="fa fa-angle-down"></i>
			</button>
			<div class="dropdown-menu">
			<a class="dropdown-item" href="'.base_url("production/Production/index_update/".$key->ID_TRANSFERER_STOCK).'">
			<i class="fa fa-edit"></i> Modifier
			</a>
			</div>';


			
			$data[] = $row;
		}

		$output = array(
			"draw" => intval($_POST['draw']),
			"recordsTotal" => $this->Model->all_data($query_principal),
			"recordsFiltered" => $this->Model->filtrer($query_filter),
			"data" => $data
		);

		echo json_encode($output);
		exit;
	}


	public function traitement()
	{
    // Récupération des données du formulaire
    $select_commande = $this->input->post('select_commande'); // IDs cochés
    $quantites       = $this->input->post('quantite');        // toutes quantités
    $id_commande     = $this->input->post('id_commande');     // IDs de chaque ligne

    // Si rien n’est coché
    if (empty($select_commande)) {
    	$this->session->set_flashdata('error', "Aucune commande sélectionnée.");
    	redirect('stock_matieres/Produits_Finis');
    }

    // Chargement du modèle
    $this->load->model('Produits_Finis_model');

    // On parcourt chaque ligne
    foreach ($id_commande as $index => $id) {

        // seulement si cette ligne a été cochée
    	if (in_array($id, $select_commande)) {

    		$data_update = [
    			'QUANTITE' => $quantites[$index],
                'IS_VALIDE' => 1,              // ou ton champ de validation
                'DATE_TRAITE' => date('Y-m-d H:i:s')
            ];

            // Mise à jour
            $this->Produits_Finis_model->update_commande($id, $data_update);
        }
    }

    $this->session->set_flashdata('success', "Traitement effectué avec succès !");
    redirect('stock_matieres/Produits_Finis');
}



}

