<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Transferer extends MY_Controller {

	public function __construct() {
		parent::__construct();
		$this->Is_Connected();
	}


	public function Is_Connected()
	{

		if (empty($this->session->userdata('SUPERBAT_ID_USER')))
		{
			redirect(base_url('Login/'));
		}
	}

	function index($value='')
	{
		$data['title']='Transferer dans stock des produits finis';
		$data['type_toles']=$this->Model->getRequete('SELECT * FROM `type_toles` order by DESCRIPTION_TOLES');
		$data['type_clous']=$this->Model->getRequete('SELECT * FROM `type_clous` order by DESCRIPTION');
		$this->load->view('Transferer_Add_View',$data);
	}



	public function addcart()
	{
		$ID_TYPE_PRODUIT = $this->input->post('ID_TYPE_PRODUIT');
		$ID_TYPE_MATIERE = $this->input->post('ID_TYPE_MATIERE');
		$NUMERO_COLIS    = $this->input->post('NUMERO_COLIS');
		$QUANTITE        = $this->input->post('QUANTITE');


		$id_cart = $ID_TYPE_PRODUIT."_".$ID_TYPE_MATIERE."_".$QUANTITE;



		$datass = array(
			'id'      => $id_cart,
			'qty'     => 1,
			'price'   => 1,
			'name'    => 'cmd',
			'ID_TYPE_PRODUIT' => $ID_TYPE_PRODUIT,
			'ID_TYPE_MATIERE' => $ID_TYPE_MATIERE,
			'NUMERO_COLIS'    => $NUMERO_COLIS,
			'QUANTITE'        => $QUANTITE
		);

		$this->cart->insert($datass);

    // construction du tableau
		$table = '
		<div class="table-responsive">
		<table class="table table-bordered table-striped table-hover">
		<tr>
		<th>#</th>
		<th>Type produit</th>
		<th>Type matière</th>
		<th>Colis</th>
		<th>Quantité</th>
		<th>Supprimer</th>
		</tr>';

		$i = 0; $j = 1;

		foreach ($this->cart->contents() as $items) {
			$i++; $j++;

        if ($items["ID_TYPE_PRODUIT"] == 1) { // TOLES
        	$type = $this->Model->getRequeteOne("
        		SELECT DESCRIPTION_TOLES 
        		FROM type_toles 
        		WHERE ID_TYPE_TOLES=".$items['ID_TYPE_MATIERE']
        	);
        	$produit = "Tôles";
        	$description = $type["DESCRIPTION_TOLES"];
        } else { // CLOUS
        	$type = $this->Model->getRequeteOne("
        		SELECT DESCRIPTION 
        		FROM type_clous 
        		WHERE ID_TYPE_CLOUS=".$items['ID_TYPE_MATIERE']
        	);
        	$produit = "Clous";
        	$description = $type["DESCRIPTION"];
        }

        $table .= '
        <tr>
        <td>'.$i.'</td>
        <td>'.$produit.'</td>
        <td>'.$description.'</td>
        <td>'.$items["NUMERO_COLIS"].'</td>
        <td>'.$items["QUANTITE"].'</td>
        <td>
        <input type="hidden" id="rowid'.$j.'" value="'.$items['rowid'].'">
        <button class="btn btn-danger btn-xs" onclick="remove_ct('.$j.')">x</button>
        </td>
        </tr>';
    }

    $table .= "</table></div>";

    if(count($this->cart->contents()) > 0){
    	$table .= '
    	<div class="card-footer">
    	<button type="submit" class="btn btn-primary btn-block">Enregistrer</button>
    	</div>';

    }

    echo $table;
}



function remove_cart()
{

	$rowid = $this->input->post('rowid');
	$this->cart->remove($rowid);
	$table = null;
	$i = 0;
	$j=1;


	$table = '
	<div class="table-responsive">
	<table class="table table-bordered table-striped table-hover">
	<tr>
	<th>#</th>
	<th>Type produit</th>
	<th>Type matière</th>
	<th>Colis</th>
	<th>Quantité</th>
	<th>Supprimer</th>
	</tr>';

	foreach ($this->cart->contents() as $items) {
		$i++; $j++;

        if ($items["ID_TYPE_PRODUIT"] == 1) { // TOLES
        	$type = $this->Model->getRequeteOne("
        		SELECT DESCRIPTION_TOLES 
        		FROM type_toles 
        		WHERE ID_TYPE_TOLES=".$items['ID_TYPE_MATIERE']
        	);
        	$produit = "Tôles";
        	$description = $type["DESCRIPTION_TOLES"];
        } else { // CLOUS
        	$type = $this->Model->getRequeteOne("
        		SELECT DESCRIPTION 
        		FROM type_clous 
        		WHERE ID_TYPE_CLOUS=".$items['ID_TYPE_MATIERE']
        	);
        	$produit = "Clous";
        	$description = $type["DESCRIPTION"];
        }

        $table .= '
        <tr>
        <td>'.$i.'</td>
        <td>'.$produit.'</td>
        <td>'.$description.'</td>
        <td>'.$items["NUMERO_COLIS"].'</td>
        <td>'.$items["QUANTITE"].'</td>
        <td>
        <input type="hidden" id="rowid'.$j.'" value="'.$items['rowid'].'">
        <button class="btn btn-danger btn-xs" onclick="remove_ct('.$j.')">x</button>
        </td>
        </tr>';
    }

    $table .= "</table></div>";

    if(count($this->cart->contents()) > 0){
    	$table .= '
    	<div class="card-footer">
    	<button type="submit" class="btn btn-primary btn-block">Enregistrer</button>
    	</div>';
    }

    // print_r($table);exit();

    echo $table;
}



public function save_transfer()
{
	foreach ($this->cart->contents() as $item) {

        // Si produit = TOLES
		$ID_TYPE_TOLES = ($item["ID_TYPE_PRODUIT"] == 1) ? $item["ID_TYPE_MATIERE"] : NULL;

        // Si produit = CLOUS
		$ID_TYPE_CLOUS = ($item["ID_TYPE_PRODUIT"] == 2) ? $item["ID_TYPE_MATIERE"] : NULL;

		$data = array(
			'ID_TYPE_PRODUIT'     => $item["ID_TYPE_PRODUIT"],
			'ID_TYPE_TOLES'       => $ID_TYPE_TOLES,
			'ID_TYPE_CLOUS'       => $ID_TYPE_CLOUS,
			'QUANTITE'            => $item["QUANTITE"],
			'NUMERO_COLIS'        => $item["NUMERO_COLIS"],
			'DATE_INSERT_TRANSFER'=> date('Y-m-d H:i:s')
		);

		$this->Model->create('transferer_prod_stock', $data);
	}
	$data['message']="<div class='alert alert-success text-center' id ='message'><b>Création d'un type de document fait avec succès</b>.</div>";
	$this->session->set_flashdata($data);
	$this->cart->destroy();
	redirect(base_url('production/Production'));
}


function liste(){
	$data['title']='Liste des transferes';

	$this->load->view('Transferer_Liste_View',$data);
}

public function listing()
{

	$query_principal ="SELECT ID_TRANSFERER_STOCK,ID_TYPE_PRODUIT ,IF (ID_TYPE_PRODUIT=1,'Toles','Clous') AS produit, type_toles.DESCRIPTION_TOLES,type_clous.DESCRIPTION AS clous, tps.ID_TYPE_CLOUS, QUANTITE, DATE_INSERT_TRANSFER, NUMERO_COLIS, user.NOM,user.PRENOM, ID_USER_RECEPTEUR  FROM transferer_prod_stock tps LEFT JOIN type_toles ON type_toles.ID_TYPE_TOLES=tps.ID_TYPE_TOLES LEFT JOIN type_clous ON type_clous.ID_TYPE_CLOUS=tps.ID_TYPE_CLOUS LEFT JOIN admin_user user ON user.ID_USER=tps.ID_USER_EXPEDITEUR  WHERE STATUT_TRANSFER=1" ;

	$var_search = !empty($_POST['search']['value']) ? $this->db->escape_like_str($_POST['search']['value']) : null;

	$limit = 'LIMIT 0,10';

	if (isset($_POST['length']) && $_POST['length'] != -1) {
		$limit = 'LIMIT ' . (isset($_POST["start"]) ? $_POST["start"] : 0) . ',' . $_POST["length"];
	}

	$order_by = '';

	$order_column = array('ID_TRANSFERER_STOCK','type_toles.DESCRIPTION_TOLES','type_clous.DESCRIPTION', 'NUMERO_COLIS','user.NOM','QUANTITE','DATE_INSERT_TRANSFER');

	$order_by = isset($_POST['order']) ? ' ORDER BY ' . $order_column[$_POST['order']['0']['column']] . '  ' . $_POST['order']['0']['dir'] : ' ORDER BY ID_TRANSFERER_STOCK ASC';

	$search = !empty($_POST['search']['value']) ?
	"AND user.NOM LIKE '%$var_search%' OR user.PRENOM LIKE '%$var_search%' OR QUANTITE_TONNE LIKE '%$var_search%' OR type_clous.DESCRIPTION LIKE '%$var_search%'  OR type_toles.DESCRIPTION_TOLES LIKE '%$var_search%' OR DATE_FORMAT(DATE_INSERT_TRANSFER, '%d/%m/%Y') LIKE '%$var_search%'  "
	: '';

	$critaire = '';

	$query_secondaire = $query_principal . ' ' . $critaire . ' ' . $search . ' ' . $order_by . '   ' . $limit;
	$query_filter = $query_principal . ' ' . $critaire . ' ' . $search;

	$resultat = $this->Model->datatable($query_secondaire);

	$data = array();
	foreach ($resultat as $key) {
		$row = array();

		$row[] = $key->NOM .' '.$key->PRENOM;
		$row[] = $key->produit;
		$row[] = $key->ID_TYPE_PRODUIT=1 ? $key->DESCRIPTION_TOLES .'('.$key->NUMERO_COLIS.')' : $key->DESCRIPTION;
		$row[] = $key->QUANTITE;		
		$row[] = date("d/m/Y", strtotime($key->DATE_INSERT_TRANSFER));

		// $row[] = '
		// <div class="modal fade" id="rendreeff'.$key->ID_TRANSFERER_STOCK.'" tabindex="-1" role="dialog" aria-labelledby="basicModal" aria-hidden="true">
		// <div class="modal-dialog">
		// <div class="modal-content">
		// <div class="modal-header">
		// <h4 class="modal-title" id="myModalLabel">Effacer</h4>
		// <button type="button" class="close" data-dismiss="modal" aria-label="Close">
		// <span aria-hidden="true">&times;</span>
		// </button>
		// </div>
		// <form id="FormData" action="'.base_url("stock_matieres/Stock_matieres/effacer/".$key->ID_TRANSFERER_STOCK).'" >
		// <div class="modal-body">

		// voulez vous supprimer le fournisseur '.$key->DESCRIPTION.'('.$key->CARACTERISTIQUE.')
		// </div>
		// <div class="modal-footer">
		// <button type="submit" class="btn btn-secondary" >Supprimer</button>
		// </div>
		// </div>
		// </div>
		// </div>

		// <div class="btn-group">
		// <button type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
		// <i class="fa fa-cogs"></i> Actions <i class="fa fa-angle-down"></i>
		// </button>
		// <div class="dropdown-menu">
		// <a class="dropdown-item" href="'.base_url("stock_matieres/Stock_matieres/index_update/".$key->ID_TRANSFERER_STOCK).'">
		// <i class="fa fa-edit"></i> Modifier
		// </a>
		// <a class="dropdown-item" data-toggle="modal" data-target="#rendreeff'.$key->ID_TRANSFERER_STOCK.'">
		// <i class="fa fa-eye"></i> Supprimer
		// </a>
		// </div>
		// </div>';



		$data[] = $row;
	}

	$output = array(
		"draw" => intval($_POST['draw']),
		"recordsTotal" => $this->Model->all_data($query_principal),
		"recordsFiltered" => $this->Model->filtrer($query_filter),
		"data" => $data
	);

	echo json_encode($output);
	exit;
}


public function listing_reception()
{

	$query_principal ="SELECT ID_TRANSFERER_STOCK,ID_TYPE_PRODUIT ,IF (ID_TYPE_PRODUIT=1,'Toles','Clous') AS produit, type_toles.DESCRIPTION_TOLES,type_clous.DESCRIPTION AS clous, tps.ID_TYPE_CLOUS, QUANTITE, DATE_INSERT_TRANSFER, NUMERO_COLIS, user.NOM,user.PRENOM, ID_USER_RECEPTEUR  FROM transferer_prod_stock tps LEFT JOIN type_toles ON type_toles.ID_TYPE_TOLES=tps.ID_TYPE_TOLES LEFT JOIN type_clous ON type_clous.ID_TYPE_CLOUS=tps.ID_TYPE_CLOUS LEFT JOIN admin_user user ON user.ID_USER=tps.ID_USER_EXPEDITEUR  WHERE STATUT_TRANSFER=2" ;

	$var_search = !empty($_POST['search']['value']) ? $this->db->escape_like_str($_POST['search']['value']) : null;

	$limit = 'LIMIT 0,10';

	if (isset($_POST['length']) && $_POST['length'] != -1) {
		$limit = 'LIMIT ' . (isset($_POST["start"]) ? $_POST["start"] : 0) . ',' . $_POST["length"];
	}

	$order_by = '';

	$order_column = array('ID_TRANSFERER_STOCK','type_toles.DESCRIPTION_TOLES','type_clous.DESCRIPTION', 'NUMERO_COLIS','user.NOM','QUANTITE','DATE_INSERT_TRANSFER');

	$order_by = isset($_POST['order']) ? ' ORDER BY ' . $order_column[$_POST['order']['0']['column']] . '  ' . $_POST['order']['0']['dir'] : ' ORDER BY ID_TRANSFERER_STOCK ASC';

	$search = !empty($_POST['search']['value']) ?
	"AND user.NOM LIKE '%$var_search%' OR user.PRENOM LIKE '%$var_search%' OR QUANTITE_TONNE LIKE '%$var_search%' OR type_clous.DESCRIPTION LIKE '%$var_search%'  OR type_toles.DESCRIPTION_TOLES LIKE '%$var_search%' OR DATE_FORMAT(DATE_INSERT_TRANSFER, '%d/%m/%Y') LIKE '%$var_search%'  "
	: '';

	$critaire = '';

	$query_secondaire = $query_principal . ' ' . $critaire . ' ' . $search . ' ' . $order_by . '   ' . $limit;
	$query_filter = $query_principal . ' ' . $critaire . ' ' . $search;

	$resultat = $this->Model->datatable($query_secondaire);

	$data = array();
	foreach ($resultat as $key) {
		$row = array();

		$row[] = $key->NOM .' '.$key->PRENOM;
		$row[] = $key->produit;
		$row[] = $key->ID_TYPE_PRODUIT=1 ? $key->DESCRIPTION_TOLES .'('.$key->NUMERO_COLIS.')' : $key->DESCRIPTION;
		$row[] = $key->QUANTITE;		
		$row[] = date("d/m/Y", strtotime($key->DATE_INSERT_TRANSFER));

		



		$data[] = $row;
	}

	$output = array(
		"draw" => intval($_POST['draw']),
		"recordsTotal" => $this->Model->all_data($query_principal),
		"recordsFiltered" => $this->Model->filtrer($query_filter),
		"data" => $data
	);

	echo json_encode($output);
	exit;
}

public function traitement()
{
    // Récupération des données du formulaire
    $select_commande = $this->input->post('select_commande'); // IDs cochés
    $quantites       = $this->input->post('quantite');        // toutes quantités
    $id_commande     = $this->input->post('id_commande');     // IDs de chaque ligne

    // Si rien n’est coché
    if (empty($select_commande)) {
        $this->session->set_flashdata('error', "Aucune commande sélectionnée.");
        redirect('produit_finis/Produits_Finis');
    }

    // On parcourt chaque ligne
    foreach ($id_commande as $index => $id) {

        // seulement si cette ligne a été cochée
        if (in_array($id, $select_commande)) {

            $data_update = [
                'QUANTITE' => $quantites[$index],
                'STATUT_TRANSFER' => 2,              // ou ton champ de validation
                'ID_USER_RECEPTEUR' => $this->session->userdata('SUPERBAT_ID_USER')
            ];

            // Mise à jour
            $this->Model->update('', $data_update);
        }
    }

    $this->session->set_flashdata('success', "Traitement effectué avec succès !");
    redirect('produit_finis/Produits_Finis');
}


}

